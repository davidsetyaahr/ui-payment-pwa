import {baseUrl } from "@/helper/baseUrl";

export const getPoint = async (callback) => {
    return callback(baseUrl);
}