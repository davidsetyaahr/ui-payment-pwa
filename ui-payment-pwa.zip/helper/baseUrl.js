export var baseUrl = "https://primtech-sistem.com/ui-payment-backoffice/public/api/";
export var baseStorageUrl = "https://primtech-sistem.com/ui-payment-backoffice/public/storage/";
