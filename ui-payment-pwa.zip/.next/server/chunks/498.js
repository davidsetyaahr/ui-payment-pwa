"use strict";
exports.id = 498;
exports.ids = [498];
exports.modules = {

/***/ 423:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ baseUrl),
/* harmony export */   "n": () => (/* binding */ baseStorageUrl)
/* harmony export */ });
var baseUrl = "https://primtech-sistem.com/ui-payment-backoffice/public/api/";
var baseStorageUrl = "https://primtech-sistem.com/ui-payment-backoffice/public/storage/";


/***/ }),

/***/ 3628:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ getListBill),
/* harmony export */   "Ah": () => (/* binding */ checkOutBill),
/* harmony export */   "Dg": () => (/* binding */ getMyPoint),
/* harmony export */   "HS": () => (/* binding */ getSummaryStudent),
/* harmony export */   "Od": () => (/* binding */ getScoreByTest),
/* harmony export */   "T": () => (/* binding */ getAttend),
/* harmony export */   "dd": () => (/* binding */ getHistoryPayment),
/* harmony export */   "gp": () => (/* binding */ getDetailPayment),
/* harmony export */   "lD": () => (/* binding */ getPrintReceipt),
/* harmony export */   "m5": () => (/* binding */ verifyPayment),
/* harmony export */   "vJ": () => (/* binding */ getClassItem),
/* harmony export */   "xf": () => (/* binding */ getResultScore)
/* harmony export */ });
/* unused harmony export getBillMonth */
/* harmony import */ var _helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(423);

const getMyPoint = async ({ data , perPage =10  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}myPoint/${id}?perpage=${perPage}`;
    if (data.startDate != "" && data.endDate != "") {
        url = `${url}&start=${data.startDate}&end=${data.endDate}`;
    }
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getHistoryPayment = async ({ data , perPage =10  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}payment/history/${id}?perpage=${perPage}`;
    if (data.startDate != "" && data.endDate != "") {
        url = `${url}&start=${data.startDate}&end=${data.endDate}`;
    }
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getDetailPayment = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}payment/detail/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getPrintReceipt = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}payment/printInvoice/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.blob();
    callback(result);
};
const getListBill = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}payment/billing/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
// update todo attend
// update filter
// attend
const getClassItem = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}classItem/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getAttend = async ({ data , perPage =10  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}attendace/${id}?perpage=${perPage}`;
    if (data.classSelected !== 0) {
        url = `${url}&class=${data.classSelected}`;
    }
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getSummaryStudent = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}summaryStudent/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getResultScore = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}score/getResult/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getScoreByTest = async ({ data  }, callback)=>{
    const id = data.id;
    const idTest = data.idTest;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}score/getScore/${id}/${idTest}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const checkOutBill = async (payload, callback)=>{
    const res = await fetch(_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F + "payment/checkout", {
        body: JSON.stringify(payload.body),
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "POST"
    });
    const result = await res.json();
    callback(result);
};
const verifyPayment = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}payment/verify/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getBillMonth = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${baseUrl}payment/get-bill-month/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};


/***/ }),

/***/ 8731:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const withAuth = (WrappedComponent)=>{
    const Wrapper = (props)=>{
        const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
        (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
            const token = localStorage.getItem("token");
            if (!token) {
                router.push("/signin");
            }
        }, []);
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(WrappedComponent, {
            ...props
        });
    };
    return Wrapper;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (withAuth);


/***/ })

};
;