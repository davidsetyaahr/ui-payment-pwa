"use strict";
exports.id = 180;
exports.ids = [180];
exports.modules = {

/***/ 5123:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _utils_api_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3939);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__, _utils_api_util__WEBPACK_IMPORTED_MODULE_1__]);
([axios__WEBPACK_IMPORTED_MODULE_0__, _utils_api_util__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// import type { AxiosRequestConfig } from 'axios';


// export interface AxiosInstanceProps extends AxiosRequestConfig {
//   token?: any;
//   isFormData?: boolean;
// }
// export interface AxiosRequestProps extends AxiosInstanceProps {
//   url: string;
// }
const axiosInstance = (props)=>{
    const { token , isFormData , ...rest } = props;
    const instance = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
        baseURL: process.env.NEXT_PUBLIC_API_URL,
        headers: {
            "Content-Type": isFormData ? "multipart/form-data" : "application/x-www-form-urlencoded",
            "Authorization": token ? `Bearer ${token}` : ""
        },
        ...rest
    });
    // instance.interceptors.request.use((request) => {
    //     console.log(request);
    //     return request;
    // });
    instance.interceptors.response.use((response)=>{
        return response.data;
    }, (err)=>{
        if (err?.response?.status === 401) {
        // handler error unauthenticated
        }
        return Promise.reject(err);
    });
    return instance;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosInstance);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3939:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R1": () => (/* binding */ apiGet)
/* harmony export */ });
/* unused harmony exports apiPost, apiPut, apiDelete */
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7104);
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(qs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _instances_axios_instances__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5123);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_instances_axios_instances__WEBPACK_IMPORTED_MODULE_1__]);
_instances_axios_instances__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const apiGet = async (props)=>{
    const { url , params , ...rest } = props;
    return (0,_instances_axios_instances__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)({
        ...rest
    }).get(url, {
        params,
        ...rest
    });
};
const apiPost = (props)=>{
    const { url , data , isFormData , ...rest } = props;
    return axiosInstance({
        ...rest
    }).post(url, !isFormData ? qs.stringify(data) : data, {
        ...rest
    });
};
const apiPut = (props)=>{
    const { url , data , ...rest } = props;
    return axiosInstance({
        ...rest
    }).put(url, qs.stringify(data), {
        ...rest
    });
};
const apiDelete = (props)=>{
    const { url , ...rest } = props;
    return axiosInstance({
        ...rest
    }).delete(url, {
        ...rest
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;