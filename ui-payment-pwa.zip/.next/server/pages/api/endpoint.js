"use strict";
(() => {
var exports = {};
exports.id = 924;
exports.ids = [924];
exports.modules = {

/***/ 4705:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ baseUrl)
/* harmony export */ });
/* unused harmony export baseStorageUrl */
var baseUrl = "https://primtech-sistem.com/ui-payment-backoffice/public/api/";
var baseStorageUrl = "https://primtech-sistem.com/ui-payment-backoffice/public/storage/";


/***/ }),

/***/ 4174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getPoint": () => (/* binding */ getPoint)
/* harmony export */ });
/* harmony import */ var _helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4705);

const getPoint = async (callback)=>{
    return callback(_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F);
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4174));
module.exports = __webpack_exports__;

})();