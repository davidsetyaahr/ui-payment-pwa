"use strict";
(() => {
var exports = {};
exports.id = 808;
exports.ids = [808];
exports.modules = {

/***/ 4705:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ baseUrl)
/* harmony export */ });
/* unused harmony export baseStorageUrl */
var baseUrl = "https://primtech-sistem.com/ui-payment-backoffice/public/api/";
var baseStorageUrl = "https://primtech-sistem.com/ui-payment-backoffice/public/storage/";


/***/ }),

/***/ 4658:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "checkOutBill": () => (/* binding */ checkOutBill),
/* harmony export */   "getAttend": () => (/* binding */ getAttend),
/* harmony export */   "getBillMonth": () => (/* binding */ getBillMonth),
/* harmony export */   "getClassItem": () => (/* binding */ getClassItem),
/* harmony export */   "getDetailPayment": () => (/* binding */ getDetailPayment),
/* harmony export */   "getHistoryPayment": () => (/* binding */ getHistoryPayment),
/* harmony export */   "getListBill": () => (/* binding */ getListBill),
/* harmony export */   "getMyPoint": () => (/* binding */ getMyPoint),
/* harmony export */   "getPrintReceipt": () => (/* binding */ getPrintReceipt),
/* harmony export */   "getResultScore": () => (/* binding */ getResultScore),
/* harmony export */   "getScoreByTest": () => (/* binding */ getScoreByTest),
/* harmony export */   "getSummaryStudent": () => (/* binding */ getSummaryStudent),
/* harmony export */   "verifyPayment": () => (/* binding */ verifyPayment)
/* harmony export */ });
/* harmony import */ var _helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4705);

const getMyPoint = async ({ data , perPage =10  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}myPoint/${id}?perpage=${perPage}`;
    if (data.startDate != "" && data.endDate != "") {
        url = `${url}&start=${data.startDate}&end=${data.endDate}`;
    }
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getHistoryPayment = async ({ data , perPage =10  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}payment/history/${id}?perpage=${perPage}`;
    if (data.startDate != "" && data.endDate != "") {
        url = `${url}&start=${data.startDate}&end=${data.endDate}`;
    }
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getDetailPayment = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}payment/detail/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getPrintReceipt = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}payment/printInvoice/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.blob();
    callback(result);
};
const getListBill = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}payment/billing/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
// update todo attend
// update filter
// attend
const getClassItem = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}classItem/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getAttend = async ({ data , perPage =10  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}attendace/${id}?perpage=${perPage}`;
    if (data.classSelected !== 0) {
        url = `${url}&class=${data.classSelected}`;
    }
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getSummaryStudent = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}summaryStudent/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getResultScore = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}score/getResult/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getScoreByTest = async ({ data  }, callback)=>{
    const id = data.id;
    const idTest = data.idTest;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}score/getScore/${id}/${idTest}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const checkOutBill = async (payload, callback)=>{
    const res = await fetch(_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F + "payment/checkout", {
        body: JSON.stringify(payload.body),
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "POST"
    });
    const result = await res.json();
    callback(result);
};
const verifyPayment = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}payment/verify/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};
const getBillMonth = async ({ data  }, callback)=>{
    const id = data.id;
    var url = `${_helper_baseUrl__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .F}payment/get-bill-month/${id}`;
    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token")
        },
        method: "GET"
    });
    const result = await res.json();
    callback(result);
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4658));
module.exports = __webpack_exports__;

})();